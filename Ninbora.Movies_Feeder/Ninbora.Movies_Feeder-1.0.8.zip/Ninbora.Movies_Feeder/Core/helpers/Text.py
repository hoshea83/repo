# Copyright (C) 2014 Ninbora [admin@ninbora.com]

import urllib
import hashlib
import HTMLParser
import re
def xbmcTo(ss):
  if isinstance(ss,unicode):
    return ss.encode('utf8')
  return ss
def xbmcFrom(ss):
  return ss.decode('utf8')
def hash(ss, size = 6):
  mm = hashlib.md5()
  if isinstance(ss,unicode):
    ss = ss.encode('utf8')
  mm.update(ss)
  return mm.hexdigest()[:size]
def buildUrl(url, params):
  def urlencode_unicode(params):
    query = ''
    for xx in params:
      s1 = xx
      if not isinstance(s1,unicode):
        s1 = str(s1).decode('utf8');
      s2 = params[xx]
      if not isinstance(s2,unicode):
        s2 = str(s2).decode('utf8');
      if ( query != '' ):
        query += '&';
      query += urllib.quote_plus(s1.encode('utf8'))
      query += '=';
      query += urllib.quote_plus(s2.encode('utf8'))
    return query
  return "{0}?{1}".format(url.encode('utf8'), urlencode_unicode(params))
def unescapeHtml(ss):
  if not isinstance(ss,unicode):
    ss = str(ss).decode('utf8');
  ss = re.sub(u'&#x(\d+);' , lambda mm : unichr(int(mm.group(1),16))  ,ss)
  ss = re.sub(u'&#(\d+);'  , lambda mm : unichr(int(mm.group(1),10))  ,ss)
  ss = re.sub(u'%(\d+)'    , lambda mm : unichr(int(mm.group(1),16))  ,ss)
  return ss