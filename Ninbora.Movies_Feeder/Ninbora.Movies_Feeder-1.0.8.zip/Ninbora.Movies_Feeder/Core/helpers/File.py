# Copyright (C) 2014 Ninbora [admin@ninbora.com]

import shutil
import os
import os.path
import zipfile
def ensureFolder(folder):
  if not os.path.exists(folder):
    try:
      os.makedirs(folder)
    except:
      return False
  return True
def cleanName(filename):
  filename = filename.replace("'","")
  filename = filename.replace("?","")
  filename = filename.replace("<","")
  filename = filename.replace(">","")
  filename = filename.replace("*","")
  filename = filename.replace("|","")
  filename = filename.replace(":","")
  filename = filename.replace("!","")
  filename = filename.replace("\\","")
  filename = filename.replace("/","_")
  return filename
def delFiles(folder, extension = '', prefix = ''):
  if (extension != '' ) :
    extension = '.' + extension
  try:
    for root, dirs, files in os.walk(folder, topdown=False):
      for name in files:
        filename = os.path.join(root, name)
        if extension == '' and prefix == '':
          os.remove(filename)
        elif extension != '' and filename.endswith(extension):
          os.remove(filename)
        elif prefix != '' and name.startswith(prefix):
          os.remove(filename)
      for name in dirs:
        dir = os.path.join(root, name)
        os.rmdir(dir)        
  except IOError:
    return
def zz(b01,b02):
    ensureFolder(b02)
    b03 = zipfile.ZipFile(b01)
    for b04 in b03.infolist():
        try:
            b05 = b04.filename
            b06 = os.path.join(b02,*b05.split('/'))
            if b05.endswith('/'):
                ensureFolder(b06)
            else:
                ensureFolder(os.path.dirname(b06))
                with open(b06,'wb') as b07:
                    b07.write( b03.read(b05) )
        except :
            pass
