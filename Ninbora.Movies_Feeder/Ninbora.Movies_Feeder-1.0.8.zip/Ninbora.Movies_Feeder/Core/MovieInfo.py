# Copyright (C) 2014 Ninbora [admin@ninbora.com]

import json
import Log
import helpers.Text as Text
import helpers.File as File
import codecs
from networks.FileLoader import *
from StreamMode import *
class MovieInfo:
  def __init__(self,nameHe,nameEn,year,id):
    self.nameHe     = Text.unescapeHtml(nameHe.strip())
    self.nameEn     = Text.unescapeHtml(nameEn.strip())
    self.year       = int(year.strip())
    self.idSubtitle = id.strip()
  def loadImdb(self):
    imdbInfo = {}
    try:
      ff = FileLoader.load('http://www.imdbapi.com/' , params = { 't' : self.nameEn , 'y' : self.year } )
      imdbInfo = json.loads(ff.data)
    except Exception , ee:
      Log.log(str(ee))
    self.setImdb(imdbInfo)
    return self.idImdb != None
  def setImdb(self,imdbInfo):
    self.imdbInfo = imdbInfo
    self.idImdb   = self.imdbInfo.get("imdbID")
  def findRating(self):
    try:
      rating = self.imdbInfo.get('imdbRating')
      if rating != None:
        return float(rating)
    except:
      return 0
  def findGenres(self):
    genre = self.imdbInfo.get('Genre')
    if not genre:
      return []
    return [xx.strip() for xx in genre.split(',')]
  def findCountries(self):
    country = self.imdbInfo.get('Country')
    if not country:
      return []
    return [xx.strip() for xx in country.split(',')]
  def asGenesis(self):
    params = {}
    params['action'] = 'play'
    params['name'  ] = '{0} ({1})'.format(self.nameEn , self.year)
    params['title' ] = self.nameEn
    params['imdb'  ] = self.idImdb[2:]
    params['year'  ] = self.year
    return Text.buildUrl('plugin://plugin.video.genesis/' , params )

  def asPulsar(self):
    return 'plugin://plugin.video.pulsar/movie/{0}/links'.format(self.idImdb)

  def asSalts(self):
    params = {}
    params['title'     ] = self.nameEn
    params['video_type'] = 'Movie'
    params['mode'      ] = 'get_sources'
    params['dialog'    ] = True
    params['year'      ] = self.year
    params['slug'      ] = u'{0}-{1}'.format(self.nameEn.replace(' ','-').lower(), self.year)
    return Text.buildUrl('plugin://plugin.video.salts/' , params )

  def asPulsarPlay(self):
    return 'plugin://plugin.video.pulsar/movie/{0}/play'.format(self.idImdb)

  def save(self, dirTarget,withThumb=False,streamMode=StreamMode.Genesis):
    name = '{0} ({1})'.format( self.nameEn.lower()[:40] , self.year )
    base = File.cleanName(name)
    dirTarget = os.path.join( dirTarget , base )
    info = os.path.join( dirTarget, '{0}.{1}'.format( base , 'nfo'  ) )
    File.ensureFolder(dirTarget)

    links = []
    if streamMode == StreamMode.Genesis:
      links.append([name,self.asGenesis()])
    if streamMode == StreamMode.Pulsar:
      links.append([name,self.asPulsar()])
    if streamMode == StreamMode.Salts:
      links.append([name,self.asSalts()])

    strm = os.path.join( dirTarget, '{0}.{1}'.format( base , 'strm' ) )
    with codecs.open(strm,'w') as ff:
      ff.write("#EXTM3U\n")
      for xx in links:
        ff.write(u'#EXTINF:{0},{1}\n'.format(0,xx[0] ))
        ff.write(u'{0}\n'.format(xx[1]))
    if withThumb:
      thumb = os.path.join( dirTarget, 'folder.jpg'.format( base , 'jpg' ))
      if os.path.exists(thumb) == False:
        FileLoader.load(self.imdbInfo.get('Poster'), '@' +  thumb )
    if os.path.exists(info):
      return False
    with codecs.open(info,'w') as ff:
      ff.write('http://www.imdb.com/title/{0}'.format(self.idImdb))
    return True
  @staticmethod
  def createFromImdb(imdbInfo):
    if imdbInfo == None:
      return None
    name   = imdbInfo.get('Title')
    year   = imdbInfo.get('Year')
    imdbId = imdbInfo.get('imdbID')
    mi = MovieInfo(name,name,year,'0')
    mi.setImdb(imdbInfo)
    return mi