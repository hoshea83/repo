# Copyright (C) 2014 Ninbora [admin@ninbora.com]

import shared
addon = shared.loadAddon(id='Ninbora.Series_Feeder')
addon.service()