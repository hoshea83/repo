# Copyright (C) 2014 Ninbora [admin@ninbora.com]
class Config:
  def __init__(self,addon):
    self.addon  = addon
  def getStr(self,name):
    return self.addon.getSetting(name)
  def setStr(self,name,value):
    self.addon.setSetting(name,value)
  def getBool(self,name):
    return self.addon.getSetting(name) == 'true'
  def setBool(self,name,value):
    if  value:
      self.addon.setSetting(name,'true')
    else:
      self.addon.setSetting(name,'false')
  def getInt(self,name):
    return int(self.addon.getSetting(name))
  def setInt(self,name,value):
    return self.addon.setSetting(name,str(value))
  def getFloat(self,name):
    return float(self.addon.getSetting(name))
  def setFloat(self,name,value):
    return self.addon.setSetting(name,str(value))