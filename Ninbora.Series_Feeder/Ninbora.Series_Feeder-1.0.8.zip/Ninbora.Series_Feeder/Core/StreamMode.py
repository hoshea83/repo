class StreamMode:
  Genesis       = 0
  Pulsar        = 1
  Salts         = 2
