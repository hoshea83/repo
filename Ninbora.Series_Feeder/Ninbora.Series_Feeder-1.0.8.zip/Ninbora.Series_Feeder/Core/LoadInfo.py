# Copyright (C) 2014 Ninbora [admin@ninbora.com]

class LoadInfo:
  def __init__(self,filter,maxFetched):
    self.filter = filter
    self.maxFetched = maxFetched
    self.fetched    = 0
    self.added      = 0
    self.addOrExist = 0
    self.episodes   = 0
  def isFetchAll(self):
    return self.maxFetched != 0 and self.fetched >= self.maxFetched