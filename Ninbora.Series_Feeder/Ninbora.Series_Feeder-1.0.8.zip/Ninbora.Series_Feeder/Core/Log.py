# Copyright (C) 2014 Ninbora [admin@ninbora.com]

def logConsole(message, filename="main.log"):
  print message

log = logConsole
